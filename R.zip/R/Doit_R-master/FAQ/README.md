FAQ
---
- [맥에서 불러들인 파일의 문자가 깨질 때](http://bit.ly/2wk0upM)
- [맥에서 그래프의 한글이 깨질 때](http://bit.ly/2yGLUdt)
- [맥에서 Java 설정하기](http://bit.ly/2hyir1r)
- [맥에서 ggiraphExtra 패키지 설치 중 오류가 발생할 경우](http://bit.ly/2xEMGZP)
- [ggChoropleth()로 만든 단계 구분도의 한글이 깨질 때](http://bit.ly/2fwHjFZ)